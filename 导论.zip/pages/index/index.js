var myCharts = require("../../utils/wxcharts")


const devicesId = "658085022" 
const api_key = "vCe5kpwyR27cjFXhWv2oSUT0tow=" 

Page({
  data: {},

  /**
   * @description 页面下拉刷新事件
   */
  onPullDownRefresh: function () {
    wx.showLoading({
      title: "正在获取"
    })
    this.getDatapoints().then(datapoints => {
      this.update(datapoints)
      wx.hideLoading()
    }).catch((error) => {
      wx.hideLoading()
      console.error(error)
    })
  },

  /**
   * @description 页面加载生命周期
   */
  onLoad: function () {
    console.log(`your deviceId: ${devicesId}, apiKey: ${api_key}`)

    //每隔6s自动获取一次数据进行更新
    const timer = setInterval(() => {
      this.getDatapoints().then(datapoints => {
        this.update(datapoints)
      })
    }, 5000)

    wx.showLoading({
      title: '加载中'
    })

    this.getDatapoints().then((datapoints) => {
      wx.hideLoading()
      this.firstDraw(datapoints)
    }).catch((err) => {
      wx.hideLoading()
      console.error(err)
      clearInterval(timer) //首次渲染发生错误时禁止自动刷新
    })
  },

  /**
   * 向OneNet请求当前设备的数据点
   * @returns Promise
   */
  getDatapoints: function () {
    return new Promise((resolve, reject) => {
      wx.request({
        url: `http://api.heclouds.com/devices/658085022/datapoints?datastream_id=ans3&limit=20`,
        header: {
          'content-type': 'application/json',
          "api-key": api_key
        },
        success: (res) => {
          const status = res.statusCode
          const response = res.data
          if (status !== 200) { // 返回状态码不为200时将Promise置为reject状态
            reject(res.data)
            return ;
          }
          if (response.errno !== 0) { //errno不为零说明可能参数有误, 将Promise置为reject
            reject(response.error)
            return ;
          }

          if (response.data.datastreams.length === 0) {
            reject("当前设备无数据, 请先运行硬件实验")
          }

          //程序可以运行到这里说明请求成功, 将Promise置为resolve状态
          resolve({
            ans3: response.data.datastreams[0].datapoints.reverse()
          })
          console.log(res.data)
        },
        fail: (err) => {
          reject(err)
        },
        
      })
    })
  },

  /**
   * @param {Object[]} datapoints 从OneNet云平台上获取到的数据点
   * 传入获取到的数据点, 函数自动更新图标
   */
  update: function (datapoints) {
    const gasData = this.convert(datapoints);

    this.lineChart_N.updateData({
      categories: gasData.categories,
      series: [{
        name: 'ans3',
        data: gasData.ans3,
        format: (val, name) => val.toFixed(2)
      }],
    })

  },

  /**
   * 
   * @param {Object[]} datapoints 从OneNet云平台上获取到的数据点
   * 传入数据点, 返回使用于图表的数据格式
   */
  convert: function (datapoints) {
    var categories = [];
    var ans3 = [];


    var length = datapoints.ans3.length
    for (var i = 0; i < length; i++) {
      categories.push(datapoints.ans3[i].at.slice(5, 19));
      
      ans3.push(datapoints.ans3[i].value);
    }
    return {
      categories: categories,
      ans3: ans3
    }
  },
  /**
   * 
   * @param {Object[]} datapoints 从OneNet云平台上获取到的数据点
   * 传入数据点, 函数将进行图表的初始化渲染
   */
  firstDraw: function (datapoints) {

    //得到屏幕宽度
    var windowWidth = 320;
    try {
      var res = wx.getSystemInfoSync();
      windowWidth = res.windowWidth;
    } catch (e) {
      console.error('getSystemInfoSync failed!');
    }

    var gasData = this.convert(datapoints);



    //新建气体检测图表
    this.lineChart_N = new myCharts({
      canvasId: 'SULgas_concentration',
      type: 'line',
      categories: gasData.categories,
      animation: false,
      enableScroll:true,
      background: '#BDE1F3',
      series: [{
        name: 'SULgas_concentration',
        color:'#BDE1F3',
        data: gasData.ans3,
        format: function (val, name) {
          return val.toFixed(2);
        }
        
      }],
      xAxis: {
        disableGrid: true
      },
      yAxis: {
        title: 'SULgas_concentration (ppm)',
        format: function (val) {
          return val.toFixed(2);
        }
      },
      width: windowWidth,
      height: 300,
      dataLabel: false,
      dataPointShape: true,
      extra: {
        lineStyle: 'curve'
      },
    });
  },
  
})
